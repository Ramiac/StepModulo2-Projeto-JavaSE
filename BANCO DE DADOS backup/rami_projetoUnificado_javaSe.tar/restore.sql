--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "PROJETO_UNIFICADO-SGE";
--
-- Name: PROJETO_UNIFICADO-SGE; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "PROJETO_UNIFICADO-SGE" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'French_France.1252';


ALTER DATABASE "PROJETO_UNIFICADO-SGE" OWNER TO postgres;

\connect -reuse-previous=on "dbname='PROJETO_UNIFICADO-SGE'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alunos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alunos (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    senha character varying(20) NOT NULL,
    nome character varying(40) NOT NULL,
    cpf character varying(11) NOT NULL,
    telefone character varying(14) NOT NULL,
    email character varying(60) NOT NULL,
    ativo boolean NOT NULL
);


ALTER TABLE public.alunos OWNER TO postgres;

--
-- Name: alunos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alunos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alunos_id_seq OWNER TO postgres;

--
-- Name: alunos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alunos_id_seq OWNED BY public.alunos.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logs (
    id integer NOT NULL,
    tipo_usuario character varying(10) NOT NULL,
    id_prof integer,
    id_aluno integer,
    root boolean,
    tipo_query character varying(10) NOT NULL,
    string_query character varying(60) NOT NULL,
    data_horario timestamp without time zone NOT NULL
);


ALTER TABLE public.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: matricul_aluno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matricul_aluno (
    id_aluno integer NOT NULL,
    id_turma integer NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.matricul_aluno OWNER TO postgres;

--
-- Name: matricul_aluno_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.matricul_aluno_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matricul_aluno_id_seq OWNER TO postgres;

--
-- Name: matricul_aluno_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.matricul_aluno_id_seq OWNED BY public.matricul_aluno.id;


--
-- Name: matricul_prof; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.matricul_prof (
    id_prof integer NOT NULL,
    id_turma integer NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.matricul_prof OWNER TO postgres;

--
-- Name: matricul_prof_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.matricul_prof_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matricul_prof_id_seq OWNER TO postgres;

--
-- Name: matricul_prof_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.matricul_prof_id_seq OWNED BY public.matricul_prof.id;


--
-- Name: professores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.professores (
    id integer NOT NULL,
    usuario character varying(20) NOT NULL,
    senha character varying(20) NOT NULL,
    nome character varying(40) NOT NULL,
    cpf character varying(11) NOT NULL,
    telefone character varying(14) NOT NULL,
    email character varying(60) NOT NULL,
    ativo boolean NOT NULL
);


ALTER TABLE public.professores OWNER TO postgres;

--
-- Name: professor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.professor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.professor_id_seq OWNER TO postgres;

--
-- Name: professor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.professor_id_seq OWNED BY public.professores.id;


--
-- Name: turmas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.turmas (
    id integer NOT NULL,
    nome character varying(40) NOT NULL,
    dia_semana character varying(14) NOT NULL,
    ativo boolean NOT NULL,
    horario character varying(5) NOT NULL
);


ALTER TABLE public.turmas OWNER TO postgres;

--
-- Name: turmas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.turmas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.turmas_id_seq OWNER TO postgres;

--
-- Name: turmas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.turmas_id_seq OWNED BY public.turmas.id;


--
-- Name: alunos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alunos ALTER COLUMN id SET DEFAULT nextval('public.alunos_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: matricul_aluno id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_aluno ALTER COLUMN id SET DEFAULT nextval('public.matricul_aluno_id_seq'::regclass);


--
-- Name: matricul_prof id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_prof ALTER COLUMN id SET DEFAULT nextval('public.matricul_prof_id_seq'::regclass);


--
-- Name: professores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professores ALTER COLUMN id SET DEFAULT nextval('public.professor_id_seq'::regclass);


--
-- Name: turmas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turmas ALTER COLUMN id SET DEFAULT nextval('public.turmas_id_seq'::regclass);


--
-- Data for Name: alunos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alunos (id, usuario, senha, nome, cpf, telefone, email, ativo) FROM stdin;
\.
COPY public.alunos (id, usuario, senha, nome, cpf, telefone, email, ativo) FROM '$$PATH$$/3038.dat';

--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logs (id, tipo_usuario, id_prof, id_aluno, root, tipo_query, string_query, data_horario) FROM stdin;
\.
COPY public.logs (id, tipo_usuario, id_prof, id_aluno, root, tipo_query, string_query, data_horario) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: matricul_aluno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.matricul_aluno (id_aluno, id_turma, id) FROM stdin;
\.
COPY public.matricul_aluno (id_aluno, id_turma, id) FROM '$$PATH$$/3043.dat';

--
-- Data for Name: matricul_prof; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.matricul_prof (id_prof, id_turma, id) FROM stdin;
\.
COPY public.matricul_prof (id_prof, id_turma, id) FROM '$$PATH$$/3044.dat';

--
-- Data for Name: professores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.professores (id, usuario, senha, nome, cpf, telefone, email, ativo) FROM stdin;
\.
COPY public.professores (id, usuario, senha, nome, cpf, telefone, email, ativo) FROM '$$PATH$$/3040.dat';

--
-- Data for Name: turmas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.turmas (id, nome, dia_semana, ativo, horario) FROM stdin;
\.
COPY public.turmas (id, nome, dia_semana, ativo, horario) FROM '$$PATH$$/3042.dat';

--
-- Name: alunos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alunos_id_seq', 1, false);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logs_id_seq', 25, true);


--
-- Name: matricul_aluno_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.matricul_aluno_id_seq', 9, true);


--
-- Name: matricul_prof_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.matricul_prof_id_seq', 10, true);


--
-- Name: professor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.professor_id_seq', 1, false);


--
-- Name: turmas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.turmas_id_seq', 1, false);


--
-- Name: alunos alunos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alunos
    ADD CONSTRAINT alunos_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: matricul_aluno matricul_aluno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_aluno
    ADD CONSTRAINT matricul_aluno_pkey PRIMARY KEY (id);


--
-- Name: matricul_prof matricul_prof_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_prof
    ADD CONSTRAINT matricul_prof_pkey PRIMARY KEY (id);


--
-- Name: professores professor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professores
    ADD CONSTRAINT professor_pkey PRIMARY KEY (id);


--
-- Name: turmas turmas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turmas
    ADD CONSTRAINT turmas_pkey PRIMARY KEY (id);


--
-- Name: matricul_aluno aluno_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_aluno
    ADD CONSTRAINT aluno_fk FOREIGN KEY (id_aluno) REFERENCES public.alunos(id);


--
-- Name: logs id_aluno; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT id_aluno FOREIGN KEY (id_aluno) REFERENCES public.alunos(id) NOT VALID;


--
-- Name: logs id_prof; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT id_prof FOREIGN KEY (id_prof) REFERENCES public.professores(id) NOT VALID;


--
-- Name: matricul_prof prof_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_prof
    ADD CONSTRAINT prof_fk FOREIGN KEY (id_prof) REFERENCES public.professores(id);


--
-- Name: matricul_aluno turma_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_aluno
    ADD CONSTRAINT turma_fk FOREIGN KEY (id_turma) REFERENCES public.turmas(id);


--
-- Name: matricul_prof turma_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.matricul_prof
    ADD CONSTRAINT turma_fk FOREIGN KEY (id_turma) REFERENCES public.turmas(id);


--
-- PostgreSQL database dump complete
--

